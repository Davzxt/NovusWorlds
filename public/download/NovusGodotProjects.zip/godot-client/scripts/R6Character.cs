using Godot;
using System.Collections.Generic;
using System.Threading.Tasks;

public partial class R6Character : CharacterBody3D
{
    [Export] public float WalkSpeed = 7.2f;
    [Export] public float JumpVelocity = 7.8f;
    [Export] public bool IsRemote;

    public Vector2 MobileMove { get; set; }

    private Node3D visual = null!;
    private AnimationPlayer anim = null!;
    private float gravity;
    private bool mobileJumpQueued;
    private NovusAvatar avatar = new();
    private float animClock;
    private string animState = "idle";
    private readonly List<Label3D> bubbles = new();
    private readonly List<string> bubbleMessages = new();
    private Label3D nameLabel = null!;
    private Node3D forceField = null!;
    private AudioStreamPlayer3D footstepSound = null!;
    private AudioStreamPlayer3D actionSound = null!;
    private int forceFieldGeneration;

    public override void _Ready()
    {
        gravity = ProjectSettings.GetSetting("physics/3d/default_gravity").AsSingle();
        visual = CreateVisual();
        AddChild(visual);
        anim = CreateAnimations();
        visual.AddChild(anim);
        ApplyAvatarColors();
        AddNameLabel();
        AddBubble();
        AddForceField();
        AddAudio();
    }

    public override void _PhysicsProcess(double delta)
    {
        if (IsRemote) return;
        var input = Input.GetVector("move_left", "move_right", "move_forward", "move_back");
        if (MobileMove.Length() > input.Length()) input = MobileMove;
        var basis = GetViewport().GetCamera3D()?.GlobalBasis ?? Basis.Identity;
        var forward = -basis.Z; forward.Y = 0; forward = forward.Normalized();
        var right = basis.X; right.Y = 0; right = right.Normalized();
        var direction = (right * input.X + forward * -input.Y).Normalized();
        var velocity = Velocity;
        velocity.X = direction.X * WalkSpeed;
        velocity.Z = direction.Z * WalkSpeed;
        var wantsJump = Input.IsActionJustPressed("jump") || mobileJumpQueued;
        if (!IsOnFloor()) velocity.Y -= gravity * 1.85f * (float)delta;
        else if (wantsJump)
        {
            velocity.Y = JumpVelocity;
            PlayActionSound();
        }
        mobileJumpQueued = false;
        Velocity = velocity;
        MoveAndSlide();
        UpdateFootsteps(direction.Length() > 0.05f && IsOnFloor());
        if (direction.Length() > 0.05f)
        {
            LookAt(GlobalPosition + direction, Vector3.Up);
            animState = "walk";
        }
        else if (IsOnFloor()) animState = "idle";
        if (!IsOnFloor()) animState = velocity.Y > 0 ? "jump" : "fall";
        AnimateClassic((float)delta);
    }

    public override void _Process(double delta)
    {
        if (IsRemote) AnimateClassic((float)delta);
    }

    public void QueueJump()
    {
        mobileJumpQueued = true;
    }

    public void Respawn(Vector3 position)
    {
        GlobalPosition = position;
        Velocity = Vector3.Zero;
        mobileJumpQueued = false;
        animState = "idle";
        AnimateClassic(0);
        if (forceField != null) forceField.Visible = true;
        HideForceFieldLater();
    }

    public void SetAvatar(NovusAvatar nextAvatar)
    {
        avatar = nextAvatar ?? new NovusAvatar();
        if (visual != null)
        {
            ApplyAvatarColors();
            if (nameLabel != null) nameLabel.Text = avatar.Username;
        }
    }

    public void SetRemoteAnimation(string animation)
    {
        animState = string.IsNullOrWhiteSpace(animation) ? "idle" : animation;
    }

    public string CurrentAnimation => animState;

    public void SetDisplayName(string username)
    {
        avatar.Username = string.IsNullOrWhiteSpace(username) ? avatar.Username : username;
        if (nameLabel != null) nameLabel.Text = avatar.Username;
    }

    public void ShowChatBubble(string message)
    {
        var clean = (message ?? "").Trim();
        if (clean.Length == 0) return;
        var bubbleText = clean.Length > 58 ? clean[..58] : clean;
        bubbleMessages.Insert(0, bubbleText);
        while (bubbleMessages.Count > 3) bubbleMessages.RemoveAt(bubbleMessages.Count - 1);
        UpdateBubbleLabels();
        var token = bubbleText;
        GetTree().CreateTimer(5).Timeout += () =>
        {
            bubbleMessages.Remove(token);
            UpdateBubbleLabels();
        };
    }

    public void HideForceFieldLater()
    {
        var generation = ++forceFieldGeneration;
        GetTree().CreateTimer(7).Timeout += () =>
        {
            if (generation == forceFieldGeneration && IsInstanceValid(forceField)) forceField.Visible = false;
        };
    }

    private Node3D CreateVisual()
    {
        return CreateBlockR6Visual();
    }

    private Node3D CreateBlockR6Visual()
    {
        var root = new Node3D { Name = "ClassicR6" };
        AddBlock(root, "Torso", new Vector3(0, 2.1f, 0), new Vector3(2, 2, 1), new Color(0.05f, 0.41f, 0.67f));
        AddPivotBlock(root, "Head", new Vector3(0, 3.65f, 0), Vector3.Zero, new Vector3(1.25f, 1.25f, 1.25f), new Color(0.96f, 0.8f, 0.19f));
        AddPivotBlock(root, "LeftArm", new Vector3(-1.35f, 2.85f, 0), new Vector3(0, -0.75f, 0), new Vector3(0.7f, 1.8f, 0.8f), new Color(0.96f, 0.8f, 0.19f));
        AddPivotBlock(root, "RightArm", new Vector3(1.35f, 2.85f, 0), new Vector3(0, -0.75f, 0), new Vector3(0.7f, 1.8f, 0.8f), new Color(0.96f, 0.8f, 0.19f));
        AddPivotBlock(root, "LeftLeg", new Vector3(-0.48f, 1.15f, 0), new Vector3(0, -0.65f, 0), new Vector3(0.85f, 1.55f, 0.85f), new Color(0.55f, 0.75f, 0.25f));
        AddPivotBlock(root, "RightLeg", new Vector3(0.48f, 1.15f, 0), new Vector3(0, -0.65f, 0), new Vector3(0.85f, 1.55f, 0.85f), new Color(0.55f, 0.75f, 0.25f));
        AddFace(root);
        return root;
    }

    private static void AddBlock(Node root, string name, Vector3 pos, Vector3 size, Color color)
    {
        var mesh = new MeshInstance3D { Name = name, Position = pos, Mesh = new BoxMesh { Size = size } };
        mesh.MaterialOverride = new StandardMaterial3D { AlbedoColor = color, Roughness = 0.75f };
        root.AddChild(mesh);
    }

    private static void AddPivotBlock(Node root, string name, Vector3 pivotPos, Vector3 meshOffset, Vector3 size, Color color)
    {
        var pivot = new Node3D { Name = name, Position = pivotPos };
        var mesh = new MeshInstance3D { Name = $"{name}Mesh", Position = meshOffset, Mesh = new BoxMesh { Size = size } };
        mesh.MaterialOverride = new StandardMaterial3D { AlbedoColor = color, Roughness = 0.68f };
        pivot.AddChild(mesh);
        root.AddChild(pivot);
    }

    private static void AddFace(Node3D root)
    {
        var head = root.FindChild("Head", true, false) as Node3D;
        if (head == null) return;
        var black = new StandardMaterial3D { AlbedoColor = Colors.Black, ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded };
        AddFacePiece(head, "LeftEye", new Vector3(-0.24f, 0.12f, -0.64f), new Vector3(0.08f, 0.18f, 0.025f), black);
        AddFacePiece(head, "RightEye", new Vector3(0.24f, 0.12f, -0.64f), new Vector3(0.08f, 0.18f, 0.025f), black);
        AddFacePiece(head, "Mouth", new Vector3(0, -0.22f, -0.64f), new Vector3(0.44f, 0.08f, 0.025f), black);
    }

    private static void AddFacePiece(Node3D parent, string name, Vector3 pos, Vector3 size, Material mat)
    {
        parent.AddChild(new MeshInstance3D { Name = name, Position = pos, Mesh = new BoxMesh { Size = size }, MaterialOverride = mat });
    }

    private void ApplyAvatarColors()
    {
        TintPart("Head", avatar.HeadColor);
        TintPart("Torso", avatar.TorsoColor);
        TintPart("LeftArm", avatar.ArmsColor);
        TintPart("RightArm", avatar.ArmsColor);
        TintPart("LeftLeg", avatar.LegsColor);
        TintPart("RightLeg", avatar.LegsColor);
        ApplyFace();
        foreach (var item in avatar.Items)
            if (item.Type == "hat") AddHatMarker(item);
    }

    private void AddNameLabel()
    {
        nameLabel = new Label3D
        {
            Name = "NameLabel",
            Text = avatar.Username,
            Position = new Vector3(0, 5.02f, 0),
            PixelSize = 0.014f,
            Billboard = BaseMaterial3D.BillboardModeEnum.Enabled,
            Modulate = Colors.White,
            OutlineModulate = Colors.Black,
            OutlineSize = 6
        };
        AddChild(nameLabel);
    }

    private void AddBubble()
    {
        for (var i = 0; i < 3; i++)
        {
            var label = new Label3D
            {
                Name = $"ChatBubble{i + 1}",
                Text = "",
                Visible = false,
                Position = new Vector3(0, 5.45f + i * 0.34f, 0),
                PixelSize = 0.0145f,
                Billboard = BaseMaterial3D.BillboardModeEnum.Enabled,
                Modulate = Colors.Black,
                OutlineModulate = Colors.White,
                OutlineSize = 14
            };
            bubbles.Add(label);
            AddChild(label);
        }
    }

    private void AddForceField()
    {
        forceField = new Node3D { Name = "ForceField" };
        var purple = new Color(0.55f, 0.02f, 1f, 0.82f);
        var gold = new Color(1f, 0.92f, 0.2f, 0.62f);
        foreach (var x in new[] { -1.28f, 1.28f })
        foreach (var z in new[] { -0.68f, 0.68f })
            AddForceFieldBar(forceField, new Vector3(x, 2.15f, z), new Vector3(0.08f, 4.25f, 0.08f), purple);
        foreach (var y in new[] { 0.08f, 4.25f })
        foreach (var z in new[] { -0.68f, 0.68f })
            AddForceFieldBar(forceField, new Vector3(0, y, z), new Vector3(2.64f, 0.08f, 0.08f), purple);
        foreach (var y in new[] { 0.08f, 4.25f })
        foreach (var x in new[] { -1.28f, 1.28f })
            AddForceFieldBar(forceField, new Vector3(x, y, 0), new Vector3(0.08f, 0.08f, 1.42f), purple);
        AddForceFieldBar(forceField, new Vector3(0, 3.8f, -0.72f), new Vector3(1.45f, 0.08f, 0.08f), gold);
        AddForceFieldBar(forceField, new Vector3(0, 3.8f, 0.72f), new Vector3(1.45f, 0.08f, 0.08f), gold);
        AddChild(forceField);
        HideForceFieldLater();
    }

    private static void AddForceFieldBar(Node3D parent, Vector3 position, Vector3 size, Color color)
    {
        parent.AddChild(new MeshInstance3D
        {
            Name = "ForceFieldBar",
            Mesh = new BoxMesh { Size = size },
            Position = position,
            MaterialOverride = new StandardMaterial3D
            {
                AlbedoColor = color,
                EmissionEnabled = true,
                Emission = color,
                EmissionEnergyMultiplier = 1.4f,
                Transparency = BaseMaterial3D.TransparencyEnum.Alpha,
                ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded
            }
        });
    }

    private void AddAudio()
    {
        actionSound = new AudioStreamPlayer3D
        {
            Stream = GD.Load<AudioStream>("res://assets/audio/button.wav"),
            VolumeDb = -5f,
            UnitSize = 8f
        };
        AddChild(actionSound);
        footstepSound = new AudioStreamPlayer3D
        {
            Stream = GD.Load<AudioStream>("res://assets/audio/bfsl-minifigfoots1.mp3"),
            VolumeDb = -10f,
            UnitSize = 9f
        };
        AddChild(footstepSound);
    }

    private void TintPart(string name, Color color)
    {
        var node = visual.FindChild(name, true, false);
        if (node is MeshInstance3D mesh)
            mesh.MaterialOverride = new StandardMaterial3D { AlbedoColor = color, Roughness = 0.72f };
        else if (node is Node3D root)
        {
            foreach (var child in root.GetChildren())
                if (child is MeshInstance3D childMesh && childMesh.Name == $"{name}Mesh")
                    childMesh.MaterialOverride = new StandardMaterial3D { AlbedoColor = color, Roughness = 0.72f };
        }
    }

    private void ApplyFace()
    {
        var mouth = visual.FindChild("Mouth", true, false) as MeshInstance3D;
        if (mouth == null) return;
        mouth.Scale = avatar.Face.Contains("serious") ? new Vector3(0.8f, 0.7f, 1) : Vector3.One;
    }

    private void AddHatMarker(NovusAvatarItem item)
    {
        if (visual.HasNode($"NovusHat_{item.Id}")) return;
        var hatY = 4.35f + (item.HatPosition.Y - 1.2f) * 0.15f;
        var hat = new MeshInstance3D
        {
            Name = $"NovusHat_{item.Id}",
            Mesh = new CylinderMesh { TopRadius = 0.95f, BottomRadius = 1.15f, Height = 0.45f },
            Position = new Vector3(item.HatPosition.X, hatY, item.HatPosition.Z),
            RotationDegrees = item.HatRotation,
            Scale = item.HatScale
        };
        hat.MaterialOverride = new StandardMaterial3D { AlbedoColor = new Color(0.08f, 0.08f, 0.08f), Roughness = 0.55f };
        visual.AddChild(hat);
        _ = TryReplaceHatWithModel(item, hat);
    }

    private async Task TryReplaceHatWithModel(NovusAvatarItem item, MeshInstance3D fallback)
    {
        if (string.IsNullOrWhiteSpace(item.ModelUrl) || !IsInstanceValid(fallback)) return;
        try
        {
            var http = new HttpRequest();
            AddChild(http);
            var err = http.Request(item.ModelUrl);
            if (err != Error.Ok) return;
            var result = await WaitForHttp(http);
            if (result.ResponseCode >= 400 || result.Body.Length == 0) return;
            var state = new GltfState();
            var document = new GltfDocument();
            if (document.AppendFromBuffer(result.Body, "", state) != Error.Ok) return;
            if (document.GenerateScene(state) is not Node3D model) return;
            model.Name = fallback.Name;
            model.Position = fallback.Position;
            model.RotationDegrees = item.HatRotation;
            model.Scale = item.HatScale;
            visual.AddChild(model);
            fallback.QueueFree();
        }
        catch (System.Exception ex)
        {
            GD.PushWarning($"Hat model fallback for {item.Name}: {ex.Message}");
        }
    }

    private static Task<HttpResult> WaitForHttp(HttpRequest http)
    {
        var tcs = new TaskCompletionSource<HttpResult>();
        http.RequestCompleted += (result, responseCode, headers, body) =>
        {
            http.QueueFree();
            if (result != (long)HttpRequest.Result.Success) tcs.TrySetException(new System.Exception($"HTTP result {result}"));
            else tcs.TrySetResult(new HttpResult { ResponseCode = responseCode, Body = body });
        };
        return tcs.Task;
    }

    private sealed class HttpResult
    {
        public long ResponseCode;
        public byte[] Body = System.Array.Empty<byte>();
    }

    private AnimationPlayer CreateAnimations()
    {
        var player = new AnimationPlayer();
        var library = new AnimationLibrary();
        library.AddAnimation("idle", new Animation { Length = 1.2f, LoopMode = Animation.LoopModeEnum.Linear });
        library.AddAnimation("walk", new Animation { Length = 0.8f, LoopMode = Animation.LoopModeEnum.Linear });
        library.AddAnimation("jump", new Animation { Length = 0.4f });
        player.AddAnimationLibrary("", library);
        return player;
    }

    private void AnimateClassic(float delta)
    {
        animClock += delta;
        var rawSwing = Mathf.Sin(animClock * (animState == "walk" ? 7.2f : 2.5f));
        var steppedSwing = Mathf.Abs(rawSwing) < 0.22f ? 0f : Mathf.Sign(rawSwing);
        var armAngle = animState == "walk" ? steppedSwing * 20f : 0f;
        var legAngle = animState == "walk" ? -steppedSwing * 18f : 0f;
        if (animState == "jump") { armAngle = -30f; legAngle = 10f; }
        if (animState == "fall") { armAngle = 14f; legAngle = -6f; }
        RotatePart("LeftArm", new Vector3(armAngle, 0, 0));
        RotatePart("RightArm", new Vector3(-armAngle, 0, 0));
        RotatePart("LeftLeg", new Vector3(legAngle, 0, 0));
        RotatePart("RightLeg", new Vector3(-legAngle, 0, 0));
        RotatePart("Head", Vector3.Zero);
        if (forceField != null && forceField.Visible) forceField.RotationDegrees += new Vector3(0, 90f * delta, 0);
    }

    private void UpdateBubbleLabels()
    {
        for (var i = 0; i < bubbles.Count; i++)
        {
            var hasMessage = i < bubbleMessages.Count;
            bubbles[i].Visible = hasMessage;
            bubbles[i].Text = hasMessage ? bubbleMessages[i] : "";
        }
    }

    private void UpdateFootsteps(bool walking)
    {
        if (IsRemote || footstepSound?.Stream == null) return;
        if (walking)
        {
            if (!footstepSound.Playing) footstepSound.Play();
        }
        else if (footstepSound.Playing) footstepSound.Stop();
    }

    private void PlayActionSound()
    {
        if (actionSound?.Stream == null) return;
        actionSound.Stop();
        actionSound.Play();
    }

    private void RotatePart(string name, Vector3 degrees)
    {
        var node = visual.FindChild(name, true, false);
        if (node is Node3D part) part.RotationDegrees = degrees;
    }
}
